<div class='container-fluid home-0'>
    <section class="product-detail col-xs-12" style="transform: none;">
        <div class="container" style="transform: none;">
            <div class="row no-page">
                <div class="col-sm-12 text-center">
                    <h1 class="sansa">404</h1>
                    <h3 class="text-center">No Result Found</h3>
                    <a href="<?= base_url() ?>">Back To Home</a>
                </div>
            </div>
        </div>
    </section>
</div>
<style>
    #owl-demo1 .item img{
        display: block;
        width: 100%;
        height: 345px;
    }
</style>
